function res=parallelize(outargs,outargs_par_dim,fstr,inargs, ...
                     inargs_par_dim,nparts,lsfdir)



[l,h]=bsub(l,outargs,fstr,inargs);

