function mi=mi_dist(X,Y)

