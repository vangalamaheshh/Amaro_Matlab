function loglik = bbinologlik(n,N,a,b)


  loglik = sum(bbinoln(n,N,a,b),1);

