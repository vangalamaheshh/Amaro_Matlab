function [ks,kspv,rs,rspv,order]=gsea_step(dat,phen,test,sets)

order=gsea_get_order(dat,phen,test);
[ks,kspv,rs,rspv]=gsea(order,sets);

