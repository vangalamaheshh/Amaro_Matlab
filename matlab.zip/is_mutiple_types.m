function res=is_multiple_types(D,t)

res=~isempty(regexp(D.supacc(t1,:),'^[a-z_A-Z0-9]+:'));

