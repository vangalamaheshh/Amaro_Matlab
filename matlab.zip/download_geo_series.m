function download_geo_series(series_id)

%%% CONTINUE HERE

