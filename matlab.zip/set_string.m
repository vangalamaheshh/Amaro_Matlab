function strs=set_string(strs,i,s)

x=cellstr(strs);
x{i}=s;
strs=strvcat(x);
