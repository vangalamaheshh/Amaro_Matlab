function x=clip_to_range_w_margin(x,r);

x(x<r(1))=r(1);
x(x>r(2))=r(2);

%if (x>r(2))
%  x=r(2);
%elseif x<r(1)
%  x=r(1);
%end
