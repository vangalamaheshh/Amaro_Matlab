function fname=replace_space_for_unix(fname)

fname=regexprep(fname,'\ ','\\ ');
fname=regexprep(fname,'\(','\\\(');
fname=regexprep(fname,'\)','\\\)');
