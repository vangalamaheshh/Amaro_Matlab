function lh=add_x_equ_y_line

ax=axis;
mn=min(ax(1),ax(3));
mx=max(ax(2),ax(4));
lh=line([mn mx],[mn mx]);

