function key = reverse_hash_lookup(value, hash)

key = NaN;

for i=1:size(hash,1)
    if hash{i,2} == value
        key = hash{i,1};
        break
    end
end

end
