function m=checkers(s1,s2);
if nargin==1 & length(s1)==2
  s2=s1(2);
  s1=s1(1);
end

m=repmat([1 0; 0 1],ceil(s1/2),ceil(s2/2));
m=m(1:s1,1:s2);



