function f=mad_factor
% make sure you use mad(x,1)

f=1/norminv(0.75);
