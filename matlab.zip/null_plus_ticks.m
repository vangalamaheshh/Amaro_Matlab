function null_plus_ticks(dat)
