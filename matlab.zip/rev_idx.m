function r=rev_idx(idx);
[dum,r]=sort(idx);

