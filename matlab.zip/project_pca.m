function prj=project_pca(dat,m,V)

prj=(dat-repmat(m,size(dat,1),1))*V;

