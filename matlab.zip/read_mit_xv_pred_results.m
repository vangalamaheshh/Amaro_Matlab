function [pred,tr,res]=read_mit_xv_pred_results(fname)


error('not implemented yet. use read_mit_pred_results');
