function conv_small(x,y)

% FIXME
