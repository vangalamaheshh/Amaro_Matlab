function nodes=find_roots(g)

% g(node,dad)=node;
nodes=find(~any(g,2) & any(g,1)');

