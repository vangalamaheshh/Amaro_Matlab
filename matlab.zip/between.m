function b=between(x,low,hi)
% b=between(x,low,hi)
%    returns a boolean vector with 1 for x values
%    in [low,hi)

b=(x>=low) & (x<hi);
