function y=closest(x,a)

[p,pi]=min(abs(x-a));
y=x(pi);