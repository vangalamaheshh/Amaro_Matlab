function pv=score_to_pvalue(s,x,h)

u=find(h);
cs=cumsum(h)/sum(h);
cs=1-cs;

sz=size(s);
[ss,si]=sort([s(:); x]);

%%% NOT FINISHED

