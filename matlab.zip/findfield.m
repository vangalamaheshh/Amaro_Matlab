function m=findfield(ca,fld)

m=size(ca,1);
n=size(ca,2);
res=cell(m,n);
for i=1:m
  for j=1:n
    res{i,j}=getfield(ca(i,j),fld);
  end
end

