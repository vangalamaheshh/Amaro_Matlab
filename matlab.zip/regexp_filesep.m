function st=regexp_filesep

st=filesep;
if st=='\'
  st='\\';
end
