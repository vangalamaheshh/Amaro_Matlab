function v=ones_in(sz,pos)

v=zeros(1,sz);
v(pos)=1;

