function conv2v6(fname)

load([fname '.mat']);
save([fname '.v6.mat'],'-V6');
unix(['gzip ' fname '.v6.mat']);

