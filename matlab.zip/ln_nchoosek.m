function r=ln_nchoosek(n,k)
r=gammaln(n+1)-gammaln(k+1)-gammaln(n-k+1);
