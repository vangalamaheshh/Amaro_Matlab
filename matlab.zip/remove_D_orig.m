function D=remove_D_orig(D)

if isfield(D,'orig')
  D=rmfield(D,{'orig'});
end

