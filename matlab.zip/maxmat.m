function [i,j,v]=maxmat(M)

[v,f]=max(M(:));
[i,j]=ind2sub(size(M),f);
