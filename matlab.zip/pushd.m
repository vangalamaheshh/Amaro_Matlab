function pushd
global SAVED_DIRS

SAVED_DIRS{end+1}=pwd;
