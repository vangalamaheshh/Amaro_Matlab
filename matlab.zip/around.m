function a=around(x,val,delta)
% a=around(x,val,delta)
%   returns a boolean vector with 1 for x values
%   in (val-delta,val+delta)

a=(x>val-delta) & (x<val+delta);
