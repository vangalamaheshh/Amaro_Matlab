function h=plot_w_margin(x,y,r,m,varargin)

