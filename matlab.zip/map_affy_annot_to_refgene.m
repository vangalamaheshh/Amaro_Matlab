function map_affy_annot_to_refgene(a,rg)

