function x=get_cell_elem(c,elem)

x=cell(size(c));
for i=1:size(c,1)
  for j=1:size(c,2)
    x{i,j}=c{i,j}(elem);
  end
end
