function st=as_filename(st)

st=regexprep(st,' ','_');
