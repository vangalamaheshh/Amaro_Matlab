function x=replace_empty(x,y)

if isempty(x)
  x=y;
end
